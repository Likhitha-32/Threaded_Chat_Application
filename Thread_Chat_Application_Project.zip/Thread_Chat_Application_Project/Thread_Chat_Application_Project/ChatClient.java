import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ChatClient implements Runnable 
{
    private ChatServer server;
    private String clientName;
    private Scanner scanner = new Scanner(System.in);

    public ChatClient(ChatServer server, String clientName) 
    {
        this.server = server;
        this.clientName = clientName;
    }

    public String getClientName() 
    {
        return clientName;
    }
    public void run() 
    {
        server.addClient(this);

        while (true) 
        {
            String input = scanner.nextLine();
            String timestampedMessage = formatMessage(clientName + ": " + input);
            server.broadcastMessage(timestampedMessage, this);
        }
    }

    public void receiveMessage(String message) 
    {
        System.out.println(clientName + " received: " + message);
    }

    public void stopClient() 
    {
        server.removeClient(this);
        scanner.close();
    }
    private String formatMessage(String message) 
    {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        return "[" + timestamp + "] " + message;
    }
}