import java.util.HashMap;
import java.util.Map;

public class ChatServer 
{
    private Map<String, ChatClient> clients = new HashMap<>();
    public synchronized void addClient(ChatClient client)
    {
        clients.put(client.getClientName(), client);
        broadcastMessage(client.getClientName() + " has joined the chat.", null);
    }   
    public synchronized void removeClient(ChatClient client) 
    {
        clients.remove(client.getClientName());
        broadcastMessage(client.getClientName() + " has left the chat.", null);
    }
    public synchronized void broadcastMessage(String message, ChatClient sender) 
    {
        for (ChatClient client : clients.values()) 
        {
            if (client != sender) 
            {
                client.receiveMessage(message);
            }
        }
    }
    public Object start() 
    {
        throw new UnsupportedOperationException("Unimplemented method 'start'");
    }
}