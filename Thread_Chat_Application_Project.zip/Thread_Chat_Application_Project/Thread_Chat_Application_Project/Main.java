public class Main 
{
    public static void main(String[] args) 
    {
        ChatServer server = new ChatServer();
        new Thread(() -> server.start()).start();

        ChatClient client1 = new ChatClient(server, "Ramcharan");
        ChatClient client2 = new ChatClient(server, "NTR");
        ChatClient client3 = new ChatClient(server, "Nani");
        ChatClient client4 = new ChatClient(server, "Prabhas");
        ChatClient client5 = new ChatClient(server, "Allu Arjun");

        new Thread(client1).start();
        new Thread(client2).start();
        new Thread(client3).start();
        new Thread(client4).start();
        new Thread(client5).start();

        try 
        {
            Thread.sleep(3000000); 
        } 
        catch (InterruptedException e) 
        {
            e.printStackTrace();
        }

        client1.stopClient();
        client2.stopClient();
        client3.stopClient();
        client4.stopClient();
        client5.stopClient();
    }
}